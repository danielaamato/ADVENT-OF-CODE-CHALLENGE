package Day1;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.*;

public class Day1EasyPartAndDifficultPart {

    public static void readFileEasyPart () throws FileNotFoundException {
        ArrayList<Integer> list = new ArrayList<>();
        int totalthree = 0;

        File file = new File("C:\\Users\\danie\\OneDrive\\Documents\\PAED\\adventOfCode\\src\\Day1\\Day1");
        FileReader fr = new FileReader(file);

        String line;
        int lastNumber = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            int accumulation = 0;

            int sumMax = 0;

            while ((line = br.readLine()) != null) {


                if (!(line.contains("\n")) && !(line.isEmpty())) {
                    accumulation += Integer.parseInt(line);
                } else {

                    list.add(accumulation);
                    if (sumMax < accumulation) {
                        sumMax = accumulation;
                        System.out.println(sumMax + "\n");
                    }

                    accumulation = 0;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Collections.sort(list);
        ArrayList<Integer> top3 = new ArrayList<Integer>(list.subList(list.size() - 3, list.size()));

        int top3Sum = 0;
        for (int i = 0; i < top3.size(); i++) {
            System.out.println(top3.get(i) + "\n");
            top3Sum += top3.get(i);
        }

        System.out.println(top3Sum);
    }



    public static void main (String[] args) throws
            FileNotFoundException {

        readFileEasyPart();

    }
}
