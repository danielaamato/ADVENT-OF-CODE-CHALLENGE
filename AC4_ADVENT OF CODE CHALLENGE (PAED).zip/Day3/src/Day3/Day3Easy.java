package Day3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Day3Easy
{

    private static int totalSum;

    private static void readFile () throws
            FileNotFoundException
    {

        String fileName = "C:\\Users\\danie\\OneDrive\\Documents\\PAED\\Day3\\src\\Day3\\Day3";
        Scanner scan = new Scanner(new File(fileName));
        totalSum = 0;

        while(scan.hasNextLine())
        {
            String line = scan.nextLine();

            int size = line.length();
            int half = line.length() / 2;

            String partOne = line.substring(0, half);
            String partTwo = line.substring(half, size);

            findMatch(partOne, partTwo);
        }

        System.out.println(totalSum);
    }

    private static void findMatch(String partOne, String partTwo)
    {
        int flag = 0;
        char match = 0;
        
        for(int i = 0; i < partOne.length() && flag == 0; i++)
        {
            for(int j = 0; j < partTwo.length() && flag == 0; j++)
            {
                if (Character.compare(partOne.charAt(i), partTwo.charAt(j)) == 0) {

                    match = partOne.charAt(i);
                    flag = 1;
                }
            }
        }
        
        if (flag == 1) {
            setPriorities(match);
        }
    }

    private static void setPriorities(char match)
    {

        switch(match) {

            case 'a':
                totalSum += 1;
                break;
            case 'b':
                totalSum += 2;
                break;
            case 'c':
                totalSum += 3;
                break;
            case 'd':
                totalSum += 4;
                break;
            case 'e':
                totalSum += 5;
                break;
            case 'f':
                totalSum += 6;
                break;
            case 'g':
                totalSum += 7;
                break;
            case 'h':
                totalSum += 8;
                break;
            case 'i':
                totalSum += 9;
                break;
            case 'j':
                totalSum += 10;
                break;
            case 'k':
                totalSum += 11;
                break;
            case 'l':
                totalSum += 12;
                break;
            case 'm':
                totalSum += 13;
                break;
            case 'n':
                totalSum += 14;
                break;
            case 'o':
                totalSum += 15;
                break;
            case 'p':
                totalSum += 16;
                break;
            case 'q':
                totalSum += 17;
                break;
            case 'r':
                totalSum += 18;
                break;
            case 's':
                totalSum += 19;
                break;
            case 't':
                totalSum += 20;
                break;
            case 'u':
                totalSum += 21;
                break;
            case 'v':
                totalSum += 22;
                break;
            case 'w':
                totalSum += 23;
                break;
            case 'x':
                totalSum += 24;
                break;
            case 'y':
                totalSum += 25;
                break;
            case 'z':
                totalSum += 26;
                break;
            case 'A':
                totalSum += 27;
                break;
            case 'B':
                totalSum += 28;
                break;
            case 'C':
                totalSum += 29;
                break;
            case 'D':
                totalSum += 30;
                break;
            case 'E':
                totalSum += 31;
                break;
            case 'F':
                totalSum += 32;
                break;
            case 'G':
                totalSum += 33;
                break;
            case 'H':
                totalSum += 34;
                break;
            case 'I':
                totalSum += 35;
                break;
            case 'J':
                totalSum += 36;
                break;
            case 'K':
                totalSum += 37;
                break;
            case 'L':
                totalSum += 38;
                break;
            case 'M':
                totalSum += 39;
                break;
            case 'N':
                totalSum += 40;
                break;
            case 'O':
                totalSum += 41;
                break;
            case 'P':
                totalSum += 42;
                break;
            case 'Q':
                totalSum += 43;
                break;
            case 'R':
                totalSum += 44;
                break;
            case 'S':
                totalSum += 45;
                break;
            case 'T':
                totalSum += 46;
                break;
            case 'U':
                totalSum += 47;
                break;
            case 'V':
                totalSum += 48;
                break;
            case 'W':
                totalSum += 49;
                break;
            case 'X':
                totalSum += 50;
                break;
            case 'Y':
                totalSum += 51;
                break;
            case 'Z':
                totalSum += 52;
                break;
        }
    }

    public static void main(String[] args) throws
            FileNotFoundException
    {
        readFile();
    }
}
