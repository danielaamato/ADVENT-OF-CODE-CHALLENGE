package Day2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Day2EasyAndDifficultPart
{

    private static void readAndDoDifficultPart() throws FileNotFoundException {

            int useOfAX = 1;
            int useOfBY = 2;
            int useOfCZ = 3;

            int loss = 0;
            int tie = 3;
            int win = 6;

            int totalScore = 0;

            int trash = 0;

            String fileName = "C:\\Users\\danie\\OneDrive\\Documents\\PAED\\Day2\\src\\Day2\\Day2";
            Scanner scan = new Scanner(new File(fileName));

            while(scan.hasNextLine()) {
                String line = scan.nextLine();

                char opponent;
                char me;

                char[] letras = line.toCharArray();

                opponent = letras[0];
                me = letras[2];


                if (Character.compare(me, 'X') == 0) {

                    if (Character.compare(opponent, 'A') == 0) {
                        totalScore += useOfCZ;
                    } else if (Character.compare(opponent, 'B') == 0) {
                        totalScore += useOfAX;
                    } else {
                        totalScore += useOfBY;
                    }
                }

                if (Character.compare(me, 'Y') == 0) {

                    totalScore += tie;

                    if (Character.compare(opponent, 'A') == 0) {
                        totalScore += useOfAX;
                    } else if (Character.compare(opponent, 'B') == 0) {
                        totalScore += useOfBY;
                    } else {
                        totalScore += useOfCZ;
                    }
                }

                if (Character.compare(me, 'Z') == 0) {

                    totalScore += win;

                    if (Character.compare(opponent, 'A') == 0) {
                        totalScore += useOfBY;
                    } else if (Character.compare(opponent, 'B') == 0) {
                        totalScore += useOfCZ;
                    } else {
                        totalScore += useOfAX;
                    }
                }
            }

            System.out.println("Your total score is: " + totalScore);
    }


    /*
        Opponent : A for Rock
                   B for Paper
                   C for Scissors

        Me : X to lose
             Y to tie
             Z to win
     */
    private static void readAndDoEasyPart() throws FileNotFoundException
    {
        int useOfAX = 1;
        int useOfBY = 2;
        int useOfCZ = 3;

        int loss = 0;
        int tie = 3;
        int win = 6;

        int totalScore = 0;

        int trash = 0;

        String fileName = "C:\\Users\\danie\\OneDrive\\Documents\\PAED\\Day2\\src\\Day2\\Day2";
        Scanner scan = new Scanner(new File(fileName));

        while(scan.hasNextLine()) {
            String line = scan.nextLine();

            char opponent;
            char me;

            char[] letras = line.toCharArray();

            opponent = letras[0];
            me = letras[2];


            if (Character.compare(me, 'X') == 0) {
                totalScore += useOfAX;
            }

            if (Character.compare(me, 'Y') == 0) {
                totalScore += useOfBY;
            }

            if (Character.compare(me, 'Z') == 0) {
                totalScore += useOfCZ;
            }

            if ((Character.compare(me, 'X') == 0) && (Character.compare(opponent, 'A')) == 0) {
                totalScore += tie;
            }
            else if ((Character.compare(me, 'Y') == 0) && (Character.compare(opponent, 'B')) == 0) {
                totalScore += tie;
            }
            else if ((Character.compare(me, 'Z') == 0) && (Character.compare(opponent, 'C')) == 0) {
                totalScore += tie;
            }
            else {

                switch (me) {

                    case 'X':

                        if (Character.compare(opponent, 'B') == 0) {
                            trash += win;
                        } else {
                            totalScore += win;
                        }

                        break;

                    case 'Y':

                        if (Character.compare(opponent, 'C') == 0) {
                            trash += win;
                        } else {
                            totalScore += win;
                        }

                        break;

                    case 'Z':

                        if (Character.compare(opponent, 'A') == 0) {
                            trash += win;
                        } else {
                            totalScore += win;
                        }

                        break;
                }
            }
        }

        System.out.println("Your total score is: " + totalScore);
        System.out.println();
        readAndDoDifficultPart();
    }




    public static void main (String[] args) throws
            FileNotFoundException
    {
        readAndDoEasyPart();
    }
}
