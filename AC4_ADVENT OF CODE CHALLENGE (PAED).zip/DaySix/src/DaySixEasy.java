import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class DaySixEasy
{

    private static void readAndDo() throws FileNotFoundException
    {
        String filename = "C:\\Users\\danie\\OneDrive\\Documents\\PAED\\DaySix\\src\\DaySix";

        Scanner scanner = new Scanner(new File(filename));

        String line = new String();

        line = scanner.nextLine();

        char[] letras = new char[line.length()];

        for(int i = 0; i < line.length(); i++)
        {
            letras[i] = line.charAt(i);
        }

        int flag = 0;
        int i;

        for(i = 0; (i < letras.length - 4); i++)
        {
            if((letras[i + 2] != letras[i + 3]) && (letras[i + 2] != letras[i + 1]) && (letras[i + 3] != letras[i + 1]))
            {
                if((letras[i] != letras[i + 1]) && (letras[i] != letras[i + 2]) && (letras[i] != letras[i + 3]))
                {
                    flag = i;

                    int total = flag + 4;

                    System.out.println(total);
                    break;
                }
            }
        }
    }

    public static void main (String[] args) throws
            FileNotFoundException
    {

        readAndDo();
    }
}
