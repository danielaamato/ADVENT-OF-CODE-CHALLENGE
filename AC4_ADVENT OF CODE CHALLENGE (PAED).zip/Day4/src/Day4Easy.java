import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Day4Easy
{

    private static int totalContains;

    public static void read() throws IOException
    {

        String filename = "C:\\Users\\danie\\OneDrive\\Documents\\PAED\\Day4\\src\\Day4";

        Scanner scanner = new Scanner(new File(filename));

        while(scanner.hasNextLine())
        {
            String line = scanner.nextLine();

            String[] splits = line.split(",");

            String[] splitTwo = splits[0].split("-");
            String[] splitsTwo = splits[1].split("-");

            int[] firstNumbers = new int[2];
            int[] secondNumbers = new int[2];

            firstNumbers[0] = Integer.parseInt(splitTwo[0]);
            firstNumbers[1] = Integer.parseInt(splitTwo[1]);
            secondNumbers[0] = Integer.parseInt(splitsTwo[0]);
            secondNumbers[1] = Integer.parseInt(splitsTwo[1]);

            verify(firstNumbers, secondNumbers);

        }

        System.out.println(totalContains);
    }


    public static void verify (int[] firstNumbers, int[] secondNumbers) {

        if ((firstNumbers[0] >= secondNumbers[0] && firstNumbers[1] <= secondNumbers[1])
         || (secondNumbers[0] >= firstNumbers[0] && secondNumbers[1] <= firstNumbers[1]))
        {
            totalContains++;
        }
    }

    public static void main (String[] args) throws IOException
    {
        totalContains = 0;
        read();
    }
}
