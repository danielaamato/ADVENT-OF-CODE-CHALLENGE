import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class DayFiveDifficult
{
    private static void read (ArrayList<Stack> listOfStacks) throws
                FileNotFoundException
        {

            String filename = "C:\\Users\\danie\\OneDrive\\Documents\\PAED\\Day5\\src\\DayFive";

            Scanner scanner = new Scanner(new File(filename));

            String line = new String();

            while(scanner.hasNextLine())
            {
                line = scanner.nextLine();

                if(line.contains("move"))
                {

                    String[] splits = line.split(" ");

                    int quantity = Integer.parseInt(splits[1]);
                    int fromStack = Integer.parseInt(splits[3]);
                    int toStack = Integer.parseInt(splits[5]);

                    delete(quantity, fromStack, toStack, listOfStacks);
                }
            }

            for(int i = 0; i < listOfStacks.size(); i++)
            {
                System.out.println(listOfStacks.get(i));
            }
        }

        private static void delete(int quantity, int fromStack, int toStack, ArrayList<Stack> listOfStacks)
        {

            if (quantity > 1) {
                Stack<Character> lettersToPush = new Stack<>();

                for(int i = 0; i < quantity; i++)
                {


                    switch(fromStack)
                    {

                        case 1:
                            char newPush = (char) listOfStacks.get(0)
                                    .get(listOfStacks.get(0)
                                                 .size() - 1);
                            listOfStacks.get(0)
                                    .pop();
                            lettersToPush.push(newPush);

                            break;

                        case 2:
                            char newPushTwo = (char) listOfStacks.get(
                                            1)
                                    .get(listOfStacks.get(1)
                                                 .size() - 1);
                            listOfStacks.get(1)
                                    .pop();
                            lettersToPush.push(newPushTwo);


                            break;

                        case 3:
                            char newPushThree = (char) listOfStacks.get(
                                            2)
                                    .get(listOfStacks.get(2)
                                                 .size() - 1);
                            listOfStacks.get(2)
                                    .pop();
                            lettersToPush.push(newPushThree);

                            break;

                        case 4:
                            char newPushFour = (char) listOfStacks.get(
                                            3)
                                    .get(listOfStacks.get(3)
                                                 .size() - 1);
                            listOfStacks.get(3)
                                    .pop();
                            lettersToPush.push(newPushFour);

                            break;

                        case 5:
                            char newPushFive = (char) listOfStacks.get(
                                            4)
                                    .get(listOfStacks.get(4)
                                                 .size() - 1);
                            listOfStacks.get(4)
                                    .pop();
                            lettersToPush.push(newPushFive);

                            break;

                        case 6:
                            char newPushSix = (char) listOfStacks.get(
                                            5)
                                    .get(listOfStacks.get(5)
                                                 .size() - 1);
                            listOfStacks.get(5)
                                    .pop();
                            lettersToPush.push(newPushSix);

                            break;

                        case 7:
                            char newPushSeven = (char) listOfStacks.get(
                                            6)
                                    .get(listOfStacks.get(6)
                                                 .size() - 1);
                            listOfStacks.get(6)
                                    .pop();
                            lettersToPush.push(newPushSeven);

                            break;

                        case 8:
                            char newPushEight = (char) listOfStacks.get(
                                            7)
                                    .get(listOfStacks.get(7)
                                                 .size() - 1);
                            listOfStacks.get(7)
                                    .pop();
                            lettersToPush.push(newPushEight);

                            break;

                        case 9:
                            char newPushNinth = (char) listOfStacks.get(
                                            8)
                                    .get(listOfStacks.get(8)
                                                 .size() - 1);
                            listOfStacks.get(8)
                                    .pop();
                            lettersToPush.push(newPushNinth);

                            break;
                    }
                }

                pushTwo(toStack, lettersToPush, quantity, listOfStacks);
            }
            else {
                switch(fromStack)
                {
                    case 1:
                        char newPush = (char) listOfStacks.get(0)
                                .get(listOfStacks.get(0)
                                             .size() - 1);
                        listOfStacks.get(0)
                                .pop();
                        push(newPush, toStack, listOfStacks);
                        break;

                    case 2:
                        char newPushTwo = (char) listOfStacks.get(1)
                                .get(listOfStacks.get(1)
                                             .size() - 1);
                        listOfStacks.get(1)
                                .pop();
                        push(newPushTwo, toStack, listOfStacks);
                        break;

                    case 3:
                        char newPushThree = (char) listOfStacks.get(2)
                                .get(listOfStacks.get(2)
                                             .size() - 1);
                        listOfStacks.get(2)
                                .pop();
                        push(newPushThree, toStack, listOfStacks);
                        break;

                    case 4:
                        char newPushFourth = (char) listOfStacks.get(
                                        3)
                                .get(listOfStacks.get(3)
                                             .size() - 1);
                        listOfStacks.get(3)
                                .pop();
                        push(newPushFourth, toStack, listOfStacks);
                        break;

                    case 5:
                        char newPushFifth = (char) listOfStacks.get(4)
                                .get(listOfStacks.get(4)
                                             .size() - 1);
                        listOfStacks.get(4)
                                .pop();
                        push(newPushFifth, toStack, listOfStacks);
                        break;

                    case 6:
                        char newPushSixth = (char) listOfStacks.get(5)
                                .get(listOfStacks.get(5)
                                             .size() - 1);
                        listOfStacks.get(5)
                                .pop();
                        push(newPushSixth, toStack, listOfStacks);
                        break;

                    case 7:
                        char newPushSeventh = (char) listOfStacks.get(
                                        6)
                                .get(listOfStacks.get(6)
                                             .size() - 1);
                        listOfStacks.get(6)
                                .pop();
                        push(newPushSeventh, toStack, listOfStacks);
                        break;

                    case 8:
                        char newPushEigth = (char) listOfStacks.get(7)
                                .get(listOfStacks.get(7)
                                             .size() - 1);
                        listOfStacks.get(7)
                                .pop();
                        push(newPushEigth, toStack, listOfStacks);
                        break;

                    case 9:
                        char newPushNinth = (char) listOfStacks.get(8)
                                .get(listOfStacks.get(8)
                                             .size() - 1);
                        listOfStacks.get(8)
                                .pop();
                        push(newPushNinth, toStack, listOfStacks);
                        break;

                }
            }
        }

    private static void pushTwo(int toStack, Stack<Character> lettersToPush, int quantity, ArrayList<Stack> listOfStacks)
    {
        for(int i = quantity - 1; i > -1; i--)
        {
            switch(toStack) {
                case 1:
                    char newPush = lettersToPush.get(i);
                    listOfStacks.get(0).push(newPush);

                    break;

                case 2:
                    char newPushTwo = lettersToPush.get(i);
                    listOfStacks.get(1).push(newPushTwo);

                    break;

                case 3:
                    char newPushThree = lettersToPush.get(i);
                    listOfStacks.get(2).push(newPushThree);

                    break;

                case 4:
                    char newPushFourth = lettersToPush.get(i);
                    listOfStacks.get(3).push(newPushFourth);

                    break;

                case 5:
                    char newPushFifth = lettersToPush.get(i);
                    listOfStacks.get(4).push(newPushFifth);

                    break;

                case 6:
                    char newPushSixth = lettersToPush.get(i);
                    listOfStacks.get(5).push(newPushSixth);

                    break;

                case 7:
                    char newPushSeventh = lettersToPush.get(i);
                    listOfStacks.get(6).push(newPushSeventh);

                    break;

                case 8:
                    char newPushEight = lettersToPush.get(i);
                    listOfStacks.get(7).push(newPushEight);

                    break;

                case 9:
                    char newPushNinth = lettersToPush.get(i);
                    listOfStacks.get(8).push(newPushNinth);

                    break;
            }
        }
    }

    private static void push (char newPush, int toStack, ArrayList<Stack> listOfStacks) {

            switch(toStack) {

                case 1:
                    listOfStacks.get(0).push(newPush);

                    break;

                case 2:
                    listOfStacks.get(1).push(newPush);

                    break;

                case 3:
                    listOfStacks.get(2).push(newPush);

                    break;

                case 4:
                    listOfStacks.get(3).push(newPush);

                    break;

                case 5:
                    listOfStacks.get(4).push(newPush);

                    break;

                case 6:
                    listOfStacks.get(5).push(newPush);

                    break;

                case 7:
                    listOfStacks.get(6).push(newPush);

                    break;

                case 8:
                    listOfStacks.get(7).push(newPush);

                    break;

                case 9:
                    listOfStacks.get(8).push(newPush);

                    break;
            }
        }

        public static void main (String[] args) throws
                FileNotFoundException
        {
            ArrayList<Stack> listOfStacks = new ArrayList<>();

            listOfStacks = stacks();
            read(listOfStacks);
        }

        private static ArrayList<Stack> stacks()
        {
            //Creamos stack inicial

            Stack<Character> firstStack = new Stack<>();

            firstStack.push('H');
            firstStack.push('R');
            firstStack.push('B');
            firstStack.push('D');
            firstStack.push('Z');
            firstStack.push('F');
            firstStack.push('L');
            firstStack.push('S');

            Stack<Character> secondStack = new Stack<>();

            secondStack.push('T');
            secondStack.push('B');
            secondStack.push('M');
            secondStack.push('Z');
            secondStack.push('R');

            Stack<Character> thirdStack = new Stack<>();

            thirdStack.push('Z');
            thirdStack.push('L');
            thirdStack.push('C');
            thirdStack.push('H');
            thirdStack.push('N');
            thirdStack.push('S');


            Stack<Character> fourthStack = new Stack<>();

            fourthStack.push('S');
            fourthStack.push('C');
            fourthStack.push('F');
            fourthStack.push('J');

            Stack<Character> fifthStack = new Stack<>();

            fifthStack.push('P');
            fifthStack.push('G');
            fifthStack.push('H');
            fifthStack.push('W');
            fifthStack.push('R');
            fifthStack.push('Z');
            fifthStack.push('B');

            Stack<Character> sixthStack = new Stack<>();

            sixthStack.push('V');
            sixthStack.push('J');
            sixthStack.push('Z');
            sixthStack.push('G');
            sixthStack.push('D');
            sixthStack.push('N');
            sixthStack.push('M');
            sixthStack.push('T');

            Stack<Character> seventhStack = new Stack<>();

            seventhStack.push('G');
            seventhStack.push('L');
            seventhStack.push('N');
            seventhStack.push('W');
            seventhStack.push('F');
            seventhStack.push('S');
            seventhStack.push('P');
            seventhStack.push('Q');

            Stack<Character> eigthStack = new Stack<>();

            eigthStack.push('M');
            eigthStack.push('Z');
            eigthStack.push('R');

            Stack<Character> ninthStack = new Stack<>();

            ninthStack.push('M');
            ninthStack.push('C');
            ninthStack.push('L');
            ninthStack.push('G');
            ninthStack.push('V');
            ninthStack.push('R');
            ninthStack.push('T');

            ArrayList<Stack> listaStacks = new ArrayList<>();

            listaStacks.add(firstStack);
            listaStacks.add(secondStack);
            listaStacks.add(thirdStack);
            listaStacks.add(fourthStack);
            listaStacks.add(fifthStack);
            listaStacks.add(sixthStack);
            listaStacks.add(seventhStack);
            listaStacks.add(eigthStack);
            listaStacks.add(ninthStack);

            return listaStacks;
        }
    }
